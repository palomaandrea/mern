function myBirthYearFunc(){
    console.log("Nací en " + 1980);
}

//el resultado será "Nací en 1980"

var EntradaAñoNacimiento = 1980;
function myBirthYearFunc(EntradaAñoNacimiento){
    console.log("Nací en " + EntradaAñoNacimiento);
}

//el resultado será "Nací en 1980"

var num1 = 10;
var num2 = 20;
function add(num1, num2){
    console.log("¡Sumando números!");
    console.log("num1 is: " + num1);
    console.log("num2 is: " + num2);
    var sum = num1 + num2;
    console.log(sum);
}

/* el resultado será el siguiente:
"30"
*/